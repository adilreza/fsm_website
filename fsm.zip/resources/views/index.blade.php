@extends('layout.master')

@section('page_title', "Homepage | Frontier Semicondructor")

@section('index_page')
    


 <!-- SLIDER  AREA Start -->
<div class="main-slider-area">
  <div class="container-fluid">
    <div class="row">
      <div class="sb-nivo-slider-wrapper kc-elm kc-css-242493">
        <div id="mainSlider" class="nivoSlider sb-slider-image"> 
        <img src="{{ URL::asset('fsm_all_web_file/fsm_image_gallery/slider/back_slide1.jpg')}}" alt="" title="#htmlcaption1_30"/>
		<img src="{{ URL::asset('fsm_all_web_file/fsm_image_gallery/slider/back_slide2.jpg')}}" alt="" title="#htmlcaption1_28" /> </div>
        <!-- sb-slider style-1 start -->
        <div id="htmlcaption1_30" class="nivo-html-caption sb-slider-content-nivo">
          <div class="sb-slider_inner container  text-left">
            <div class="wow fadeInUpBig" data-wow-duration="1.2s" data-wow-delay="0s">
              <h2 class="sb-slider-title">Welcome to Frontier Semiconductor</h2>
            </div>
            <div class="wow slideInRight" data-wow-duration="2s" data-wow-delay="0s">
              <h1 class="sb-slider-sub-title"> Range of Advanced Metrology Products</h1>
            </div>
            <div class="wow slideInRight" data-wow-duration="2s" data-wow-delay="0s">
              <h1 class="sb-slider-sub-title">We Are Creative </h1>
            </div>
            <div class="wow slideInRight" data-wow-duration="3s" data-wow-delay="0s">
              <p  class="sb-slider-descript"> We make solutions for semiconductor, LED, Solar, FPD, Data Storage and MEMS applications</p>
            </div>
            <div class="sb-slider-button wow bounceInUp sb-button-button-area" data-wow-duration="3s" data-wow-delay="0s"> <a class="sb-active-button" href="https://themeforest.net/user/sbtechnosoft/portfolio">SEE DETAILS</a> </div>
          </div>
        </div>
        <!-- sb-slider style-1 end --> 
        
        <!-- sb-slider style-1 start -->
        <div id="htmlcaption1_28" class="nivo-html-caption sb-slider-content-nivo">
          <div class="sb-slider_inner container">
            <div class="wow fadeInUpBig" data-wow-duration="1.2s" data-wow-delay="0s">
              <h2 class="sb-slider-title">Welcome to Frontier Semicondructor</h2>
            </div>
            <div class="wow fadeInUpBig" data-wow-duration="1.5s" data-wow-delay="0s">
              <h1 class="sb-slider-sub-title">Range of Advanced Metrology Products</h1>
            </div>
            <div class="wow fadeInUpBig" data-wow-duration="2s" data-wow-delay="0s">
              <p  class="sb-slider-descript">We have over 25 years experience in stress measurement, film adhesion testing, wafer topography metrology, and electrical characterization</p>
            </div>
            <div class="sb-slider-button wow  bounceInUp  sb-button-button-area" data-wow-duration="3s" data-wow-delay="0.5s"> <a class="sb-active-button" href="https://themeforest.net/user/sbtechnosoft/portfolio">SEE DETAILS</a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Slider Wrapper End -->
<!-- Our Featured Wrapper Start -->
<div class="featured-wrapper">
<div class="container">
<div class="section-title">
<h2>Our Features </h2>
<div class="separator"></div>
</div>
<div class="row">
<div class="col-md-6 col-lg-3 no-padding">
<div class="featured-box">
<span class="icon icon-picture"></span>
  <h5>Stress Measurement</h5>
  <p>The evaluation of stress in silicon devices is extremely important in the development of next...</p>
  <a href="javascript:void(0)" class="bttn">Read More</a>
  </div>
</div> 
<div class="col-md-6 col-lg-3 no-padding">
<div class="featured-box">
<span class="icon icon-gears"></span>
  <h5>Film Adhesion Testing</h5>
  <p>Three methods of measuring thin film adhesion have been developed and evaluated</p>
  <a href="javascript:void(0)" class="bttn">Read More</a>
  </div>
</div> 
<div class="col-md-6 col-lg-3 no-padding">
<div class="featured-box">
<span class="icon icon-lightbulb"></span>
  <h5>Wafer Topography Metrology</h5>
  <p>It is a long established fact that a reader.</p>
  <a href="javascript:void(0)" class="bttn">Read More</a>
  </div>
</div> 
<div class="col-md-6 col-lg-3 no-padding">
<div class="featured-box">
<span class="icon icon-phone"></span>
  <h5>Electrical Characterization</h5>
  <p>It is a long established fact that a reader.</p>
  <a href="javascript:void(0)" class="bttn">Read More</a>
  </div>
</div> 
</div>
</div>
</div>
<!-- Our Featured Wrapper Start -->
<!-- Our Services Wrapper Start -->
<section class="our-services-wrapper">
<div class="container">
<div class="section-title">
<h2>Our Services</h2>
<div class="separator"></div>
</div>
<div class="row">
<div class="col-md-6 col-lg-4">
  <div class="single-services">
    <div class="media"> <i class="mt-2 icon icon-picture"></i>
      <div class="media-body"> <h3><a href="javascript:void(0)">Web Design</a></h3>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6 col-lg-4">
  <div class="single-services">
    <div class="media"> <i class="mt-2 icon icon-pencil"></i>
      <div class="media-body"> <h3><a href="javascript:void(0)">Development</a></h3>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6 col-lg-4">
  <div class="single-services">
    <div class="media"> <i class="mt-2 icon icon-mobile"></i>
      <div class="media-body"> <h3><a href="javascript:void(0)">Mobile Apps</a></h3>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6 col-lg-4">
  <div class="single-services">
    <div class="media"> <i class="mt-2 icon icon-basket"></i>
      <div class="media-body"> <h3><a href="javascript:void(0)">Ecommerce</a></h3>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6 col-lg-4">
  <div class="single-services">
    <div class="media"> <i class="mt-2 icon icon-strategy"></i>
      <div class="media-body"> <h3><a href="javascript:void(0)">Analytics</a></h3>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
      </div>
    </div>
  </div>
</div>
<div class="col-md-6 col-lg-4">
  <div class="single-services">
    <div class="media"> <i class="mt-2 icon icon-chat"></i>
      <div class="media-body"> <h3><a href="javascript:void(0)">Great Support</a></h3>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout</p>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</section>
<!-- Our Services Wrapper End -->
<!-- Our Team Wrapper Start -->
<div class="our-team-wrapper">
<div class="container">
<div class="row">
<div class="col-xl-4 col-md-5">
<div class="business-title-left">
<h2>Team Members</h2>
<span class="title-border-left"></span>
</div>
<div class="team-members-left">
<p>At vero eos et accusamus et iusto odioarweres dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecatisdgh cupiditate nonprovident dfgdftr.</p>
<a href="javascript:void(0)" class="bttn">Check Our Team</a> </div>
</div>
<div class="col-xl-8 col-md-7">
<div class="team-members-right">
<div class="owl-carousel team-members">
  <div class="item hover01">
    <figure><img src="http://via.placeholder.com/290x290/000/fff" alt="" class=""></figure>
    <div class="team-caption">
	<a href="#">Jhon Smith</a>
    <h3>Director</h3>
	</div>
  </div>
  <div class="item hover01">
    <figure><img src="http://via.placeholder.com/290x290/000/fff" alt="" class=""></figure>
    <div class="team-caption">
	<h3><a href="#">Jhon Smith</a></h3>
    <p>Director</p>
	</div>
  </div>
  <div class="item hover01">
    <figure><img src="http://via.placeholder.com/290x290/000/fff" alt="" class=""></figure>
    <div class="team-caption">
	<h3><a href="#">Jhon Smith</a></h3>
    <p>Director</p>
	</div>
  </div>
  <div class="item hover01">
    <figure><img src="http://via.placeholder.com/290x290/000/fff" alt="" class=""></figure>
    <div class="team-caption">
	<h3><a href="#">Jhon Smith</a></h3>
    <p>Director</p>
	</div>
  </div>
  <div class="item hover01">
    <figure><img src="http://via.placeholder.com/290x290/000/fff" alt="" class=""></figure>
    <div class="team-caption">
	<h3><a href="#">Jhon Smith</a></h3>
    <p>Director</p>
	</div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- Our Team Wrapper End -->
<!-- Numbering Wrapper Start -->
<div class="counter-wrapper">
  <div class="container text-center">
    <div class="row">
      <div class="col-lg-3 col-md-6">
        <div class="counter">
          <div class="counter-icon-box">
		 <div class="counter-icon">
		 <div class="icon"><a href="#"><i class="icon icon-clock"></i></a></div>
		 </div>
          <div class="count-description">
		  <div class="number animateNumber" data-num="6535"> <span>6535+</span></div>
          <p>Hours Worked</p>
        </div>
		</div>
      </div>
	  </div>
      <div class="col-lg-3 col-md-6">
        <div class="counter">
          <div class="counter-icon-box">
		 <div class="counter-icon">
		 <div class="icon"><a href="#"><i class="icon icon-mobile"></i></a></div>
		 </div>
          <div class="count-description">
		  <div class="number animateNumber" data-num="585"> <span>585+</span></div>
          <p>Projects Completed</p>
        </div>
		</div>
      </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="counter">
          <div class="counter-icon-box">
		 <div class="counter-icon">
		 <div class="icon"><a href="#"><i class="icon icon-presentation"></i></a></div>
		 </div>
          <div class="count-description">
		  <div class="number animateNumber" data-num="28"> <span>28+</span></div>
          <p>Theme Experts</p>
        </div>
		</div>
      </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="counter">
          <div class="counter-icon-box">
		 <div class="counter-icon">
		 <div class="icon"><a href="#"><i class="icon icon-trophy"></i></a></div>
		 </div>
          <div class="count-description">
		  <div class="number animateNumber" data-num="775"> <span>6535+</span></div>
          <p>Awards Won</p>
        </div>
		</div>
      </div>
      </div>
    </div>
  </div>
</div>
<!-- Numbering Wrapper End -->
<!-- Our Blog Wrapper Start -->
<div class="blog-wrapper">
<div class="container">
<div class="section-title">
<h2><i> <b>FSM UPCOMMING PRODUCTS</b></i></h2>
<div class="separator"></div>
</div>
<div class="row">
<div class="col-md-6">
<div class="blog_box_wrapper">
  <div class="blog_img_wraper"> <img src="http://via.placeholder.com/570x380/000/fff" alt=""> </div>
  <div class="blog_icon_overlay">
    <ul>
      <li> 19 <span> JUNE</span> </li>
      <li> 02 <span> COM.</span> </li>
      <li> <img class="img-responsive" src="http://via.placeholder.com/65x69/000/fff" alt=""> </li>
    </ul>
  </div>
  <div class="blog_btm_cntnt">
    <h2>Where does it come from</h2>
    <p class="pad-b-10">Integer dignissim egestas est, id tristique eros pharetra sit amet. Duis et ipsum pellentesque, porta ante.</p>
    <a href="javascript:void(0)" class="tb_toppadder20">read more</a> </div>
</div>
</div>
<div class="col-md-6">
<div class="blog_box_wrapper">
  <div class="blog_img_wraper"> <img src="http://via.placeholder.com/570x380/000/fff" alt=""> </div>
  <div class="blog_icon_overlay">
    <ul>
      <li> 19 <span> JUNE</span> </li>
      <li> 02 <span> COM.</span> </li>
      <li> <img class="img-responsive" src="http://via.placeholder.com/65x69/000/fff" alt=""> </li>
    </ul>
  </div>
  <div class="blog_btm_cntnt">
    <h2>Duis ultricies aliquet mauris</h2>
    <p class="pad-b-10">Integer dignissim egestas est, id tristique eros pharetra sit amet. Duis et ipsum pellentesque, porta ante.</p>
    <a href="javascript:void(0)" class="tb_toppadder20">read more</a> </div>
</div>
</div>
</div>
</div>
</div>
<!-- Our Blog Wrapper End -->

<!-- Testimonials Wrapper End -->
<section class="testimonials-wrapper">
<div class="container">
<div class="section-title">
<h2>What Clients Says</h2>
<div class="separator"></div>
</div>
<div class="two-item-carousel owl-carousel owl-theme">
<!--Testimonial Block-->
<div class="testimonial-block">
  <div class="inner-box">
    <div class="image"> <img src="images/comments1.png" alt="" /> </div>
    <div class="content">
      <div class="quote-icon fa fa-quote-right"></div>
      <div class="author-info">Jeson Jons <span>/ CEO at Showroom Prohub</span></div>
      <div class="text">Sed elit quam, iaculis sed semper sit amet udin vitae nibh. at magna akal semperFusce commodo molestie luctus.Lorem ipsum Dolor tusima olatiup.</div>
    </div>
  </div>
</div>
<!--Testimonial Block-->
<div class="testimonial-block">
  <div class="inner-box">
    <div class="image"> <img src="images/comments2.png" alt="" /> </div>
    <div class="content">
      <div class="quote-icon fa fa-quote-right"></div>
      <div class="author-info">Mark Warren <span>/ Managerment at Envato</span></div>
      <div class="text">Sed elit quam, iaculis sed semper sit amet udin vitae nibh. at magna akal semperFusce commodo molestie luctus.Lorem ipsum Dolor tusima olatiup.</div>
    </div>
  </div>
</div>
<!--Testimonial Block-->
<div class="testimonial-block">
  <div class="inner-box">
    <div class="image"> <img src="images/comments3.png" alt="" /> </div>
    <div class="content">
      <div class="quote-icon fa fa-quote-right"></div>
      <div class="author-info">Les Stone <span>/ CEO at Showroom INC</span></div>
      <div class="text">Sed elit quam, iaculis sed semper sit amet udin vitae nibh. at magna akal semperFusce commodo molestie luctus.Lorem ipsum Dolor tusima olatiup.</div>
    </div>
  </div>
</div>
<!--Testimonial Block-->
<div class="testimonial-block">
  <div class="inner-box">
    <div class="image"> <img src="images/comments2.png" alt="" /> </div>
    <div class="content">
      <div class="quote-icon fa fa-quote-right"></div>
      <div class="author-info">John Doe <span>/ Managerment at Envato</span></div>
      <div class="text">Sed elit quam, iaculis sed semper sit amet udin vitae nibh. at magna akal semperFusce commodo molestie luctus.Lorem ipsum Dolor tusima olatiup.</div>
    </div>
  </div>
</div>
</div>
</div>
</section>
<!-- News Letter Wrapper End -->



@endsection