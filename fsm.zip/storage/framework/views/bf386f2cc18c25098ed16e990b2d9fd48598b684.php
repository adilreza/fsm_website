<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $__env->yieldContent('page_title'); ?></title>
<link href="<?php echo e(URL::asset('fsm_all_web_file/assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('fsm_all_web_file/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('fsm_all_web_file/css/one.css')); ?>" id="style_theme" rel="stylesheet">
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::asset('fsm_all_web_file/fsm_image_gallery/logo/fsm_logo_png.png')); ?>">

<!-- page independent js or css file -->
  <?php echo $__env->yieldContent('custome_static'); ?>

<!-- end of file inclusion -->


</head>
<body>
<!-- Pre Loader -->
<div id="dvLoading"></div>
<!-- Top Wrapper Start -->



<!-- Top Wrapper End -->
<!-- Header Logo Area Start -->
<div class="header-logo-area">
  <div class="container">
    <div class="row">
      <div class="col-xl-5 col-lg-3 col-md-12">

      <div class="logo"> <a class="main_sticky_main_l" href="<?php echo e(route('index')); ?>" title="Frontier Semiconductor"> F<span>SM</span></a> </div>

      




      </div>
      <div class="col-xl-7 col-lg-9 col-md-12 d-none d-lg-block d-md-block">
        <div class="row">
          <div class="col-md-4 col-sm-4">
            <div class="header-logo-address">
              <div class="header-logo-icon"> <i class="fa fa-phone-square"></i> </div>
              <div class="header-logo-text">
                <p>+1 408 432 8838</p>
                <p>+1 408 232 1115</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-sm-4">
            <div class="header-logo-address">
              <div class="header-logo-icon"> <i class="fa fa-envelope"></i> </div>
              <div class="header-logo-text">
                <p>fsm100@frontiersemi.com</p>
                <p>fsm100@frontiersemi.com</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-sm-4">
            <div class="header-logo-address last-child">
              <div class="header-logo-icon"> <i class="fa fa-globe"></i> </div>
              <div class="header-logo-text">
                <p>www.website.com</p>
                <p>www.test.com</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Header Logo Area End -->
<!-- Menu Area Start -->
<div class="mainmenu-area header-sticky bg-dark-1">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 d-none d-md-block d-lg-block">
          <div class="main-menu-area">
            <nav>
              <ul>
              <li class="active"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
				<li><a href="services.html">Services</a></li>
                <li><a href="#">Gallery<i class="fa fa-angle-down"></i></a>
                  <ul class="dropdown_menu">
                    <li><a href="grid-gallery.html">Grid Gallery</a></li>
                    <li><a href="full-gallery.html">Full Width Gallery</a></li>
                    <li><a href="masonry-gallery.html">Masonry Gallery</a></li>
                    <li><a href="modern-gallery.html">Modern Gallery</a></li>
                  </ul>
                </li>				
                <li class="meg-drp-menu"><a href="#">SERIES <i class="fa fa-angle-down"></i></a>
                  <ul class="mega-menu">
                    <li>
                      <h2>128 SERIES</h2>
                      <hr style="background:#4AC8ED;padding:0.2px; width:80%">
                        <ul>
                          <li><a href="">128L C2C</a></li>
                          <li><a href="">128L </a></li>
                          <li><a href="">128L 128NT</a></li>
                          <li><a href="">128G-450</a></li>
                          <li><a href="">128 C2C</a></li>
                          
                        </ul>
                    </li>
					          <li>
                      <h2>413 SERIES</h2>
                      <hr style="background:#4AC8ED;padding:0.2px; width:80%">
                        <ul>
                          <li><a href="">413 C2C</a></li>
                          <li><a href="">413 SA</a></li>
                          <li><a href="">413 PR</a></li>
                          <li><a href="">413 MOT</a></li>


                        </ul>
                  </li>
					          <li>
                      <h2>500 SERIES</h2>
                      <hr style="background:#4AC8ED;padding:0.2px; width:80%">
                        <ul>
                          <li><a href="accordion.html">500TC</a></li>
                        
                        </ul>
                     </li>
                    <li>
                      <h2>900 SERIES</h2>
                      <hr style="background:#4AC8ED;padding:0.2px; width:80%">
                        <ul>
                          <li><a href="">900 C2C</a></li>
                          <li><a href="">900TC-VAC</a></li>
                         
                        </ul>
                    </li>


                    
                  </ul>
                </li>
                <li><a href="#">Pages<i class="fa fa-angle-down"></i></a>
                
                    <ul class="dropdown_menu">
                          <li><a href="about-us.html">About Us</a></li>
                          <li><a href="services.html">Services</a></li>
                          <li><a href="faq.html">FAQ</a></li>
                          <li><a href="our-team.html">Our Team</a></li>
                          <li><a href="testimonials.html">Testimonials</a></li>
                          <li><a href="pricing.html">Pricing</a></li>
                          <li><a href="appointment.html">Appointment</a></li>
                    </ul>
                </li>
              <li><a href="<?php echo e(URL::to('/product_fullwidth')); ?>">Products </a></li>
              <li><a href="<?php echo e(URL::to('/contact_us')); ?>">Contact Us</a></li>
              </ul>
			<div class="search-form d-sm-none d-md-none d-xl-block">
              <form method="post" action="contact-us.html">
                <div class="form-group clearfix">
                  <input name="email" value="" placeholder="Search" required="" type="email">
                  <button type="submit" class="theme-btn subscribe-btn"><span class="fa fa-search"></span></button>
                </div>
              </form>
            </div>	  
            </nav>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 d-block d-md-none d-lg-none"> 
          <!-- Mobile Menu Area Start -->
          <div class="mobile-menu-area">
            <div class="mobile-menu">
              <nav id="mobile-menu-active">
                <ul>
                <li class="active"><a href="index.html">Home</a></li>
                <li><a href="about-us.html">About Us</a></li>
				<li><a href="services.html">Services</a></li>
                <li><a href="#">Gallery</a>
                  <ul class="dropdown_menu">
                    <li><a href="grid-gallery.html">Grid Gallery</a></li>
                    <li><a href="full-gallery.html">Full Width Gallery</a></li>
                    <li><a href="masonry-gallery.html">Masonry Gallery</a></li>
                    <li><a href="modern-gallery.html">Modern Gallery</a></li>
                  </ul>
                </li>				
                <li class="meg-drp-menu"><a href="#">Features</a>
                  <ul class="mega-menu">
                    <li>
                      <a href="#">Pages</a>
                      <ul>
                        <li><a href="about-us.html">About Us</a></li>
						<li><a href="services.html">Services</a></li>
                        <li><a href="faq.html">FAQ</a></li>
                        <li><a href="our-team.html">Our Team</a></li>
                        <li><a href="testimonials.html">Testimonials</a></li>
                        <li><a href="pricing.html">Pricing</a></li>
                        <li><a href="appointment.html">Appointment</a></li>
                      </ul>
                    </li>
					<li>
					  <a href="#">Extras</a>
                      <ul>
                       <li><a href="404.html">404</a></li>
                       <li><a href="503.html">503</a></li>
                       <li><a href="coming-soon.html">Coming Soon</a></li>
					   <li><a href="login.html">Login</a></li>
					   <li><a href="register.html">Register</a></li>
					   <li><a href="search-results.html">Search results</a></li>
					   <li><a href="privacy-policy.html">Terms of use</a></li>
                      </ul>
                    </li>
					<li>
					  <a href="#">Components</a>
                      <ul>
                        <li><a href="accordion.html">Accordion</a></li>
                        <li><a href="buttons.html">Buttons</a></li>
                        <li><a href="grid.html">Grid</a></li>
                        <li><a href="forms.html">Forms</a></li>
						<li><a href="tabs.html">Tabs</a></li>
						<li><a href="table-styles.html">Table styles</a></li>
						<li><a href="typography.html">Typography</a></li>
                      </ul>
                    </li>
                    <li>
					  <a href="#">Blog</a>
                      <ul>
					    <li><a href="blog-classic.html">Blog classic</a></li>
						<li><a href="blog-grid.html">Blog grid</a></li>
                        <li><a href="blog-left.html">Blog Left</a></li>
                        <li><a href="blog-right.html">Blog Right</a></li>
                        <li><a href="blog-fullwidth.html">Blog Full Width</a></li>
                        <li><a href="blog-details.html">Blog Details</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li><a href="#">Pages</a>
                  <ul class="dropdown_menu">
                        <li><a href="about-us.html">About Us</a></li>
						<li><a href="services.html">Services</a></li>
                        <li><a href="faq.html">FAQ</a></li>
                        <li><a href="our-team.html">Our Team</a></li>
                        <li><a href="testimonials.html">Testimonials</a></li>
                        <li><a href="pricing.html">Pricing</a></li>
                        <li><a href="appointment.html">Appointment</a></li>
                  </ul>
                </li>
                <li><a href="#">Blog</a>
                  <ul class="dropdown_menu">
                <li><a href="blog-classic.html">Blog classic</a></li>
                <li><a href="blog-grid.html">Blog grid</a></li>
                <li><a href="blog-left.html">Blog Left</a></li>
                <li><a href="blog-right.html">Blog Right</a></li>
                <li><a href="blog-fullwidth.html">Blog Full Width</a></li>
                <li><a href="blog-details.html">Blog Details</a></li>
                  </ul>
                </li>
                <li><a href="contact-us.html">Contact Us</a></li>
              </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Mobile Menu Area End --> 
<!-- common header End-->


<?php echo $__env->yieldContent('index_page'); ?>

<?php echo $__env->yieldContent('about_us_page'); ?>
<?php echo $__env->yieldContent('contact_us_page'); ?>
<?php echo $__env->yieldContent('login_page'); ?>
<?php echo $__env->yieldContent('registration_page'); ?>
<?php echo $__env->yieldContent('privacy_policy_page'); ?>
<?php echo $__env->yieldContent('faq_page'); ?>
<?php echo $__env->yieldContent('services_page'); ?>


<?php echo $__env->yieldContent('aacordion_page'); ?>
<?php echo $__env->yieldContent('product_fullwidth_page'); ?>
<?php echo $__env->yieldContent('product_fullwidth2_page'); ?>

<?php echo $__env->yieldContent('appointment_page'); ?>

<?php echo $__env->yieldContent('blog_classic_page'); ?>

<?php echo $__env->yieldContent('product_details_page'); ?>

<?php echo $__env->yieldContent('our_team_page'); ?>

<?php echo $__env->yieldContent('m404_page'); ?>
<?php echo $__env->yieldContent('m503_page'); ?>









<!-- common footer start -->

  <section class="newsletter">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-12">
          <h4><span class="text-primary">Subscribe</span> <br>
            For Latest <span class="text-primary">Update</span></h4>
        </div>
        <div class="col-lg-9 col-12">
          <form>
            <div class="form-group">
              <input class="form-control" id="exampleInputName" placeholder="Your name" type="text">
            </div>
            <div class="form-group">
              <input class="form-control" id="exampleInputEmail" placeholder="Your email" type="email">
            </div>
            <button class="bttn">Subscribe</button>
          </form>
        </div>
      </div>
    </div>
  </section>
  <!-- News Letter Wrapper End -->
  <!-- Testimonials Wrapper End -->
  <!-- Footer Wrapper End -->
  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-xl-3 col-md-6">
          <div class="footer-text"> 
           <a class="footer-logo" href="<?php echo e(route('index')); ?>" title="Frontier Semiconductor"><img src="<?php echo e(URL::asset('fsm_all_web_file/fsm_image_gallery/logo/fsm_logo_png.png')); ?>" width="120px" height="60px" alt=""></a> 

            <p>Frontier Semiconductor is the leading manufacturer of stress measurement tools for semiconductor, MEMS, optoelectronic, and flat panel applications.</p>
            <div class="social-icons"> <a href="javascript:void(0)" class="bttn"> <i class="fa fa-twitter"></i> </a> <a href="javascript:void(0)" class="bttn"><i class="fa fa-linkedin"></i></a> <a href="javascript:void(0)" class="bttn"> <i class="fa fa-facebook"></i> </a> <a href="javascript:void(0)" class="bttn"> <i class="fa fa-skype"></i> </a> <a href="javascript:void(0)" class="bttn"> <i class="fa fa-pinterest-p"></i> </a> </div>
          </div>
        </div>
        <div class="col-xl-2 col-md-3">
          <div class="links">
            <h3>Links</h3>
            <ul class="">
            <li><a href="<?php echo e(route('index')); ?>">Home Page</a></li>
            <li><a href="<?php echo e(route('about_us')); ?>">About Us</a></li>
            <li><a href="<?php echo e(route('contact_us')); ?>">Contact Us</a></li>
            <li><a href="<?php echo e(route('services')); ?>">Our Services</a></li>
           
            </ul>
          </div>
        </div>
        <div class="col-xl-3 col-md-3">
          <div class="location">
            <h3>Location</h3>
            <ul>
              <li>Corporate Head Office. </li>
              <li><i class="fa fa-home"></i>165 Topaz st., Milpitas, CA 95035 </li>
              <li><i class="fa fa-phone"></i> <a href="#">+1 408 432 8838</a></li>
              <li><i class="fa fa-envelope"></i> <a href="mailto:">fsm100@frontiersemi.com</a></li>
            </ul>
          </div>
        </div>
        <div class="col-xl-4 col-md-12">
          <div class="instagram">
            <h3>Instagram</h3>
            <ul class="row gram-image">
              <li class="col-xs-4 col-4"><a href="#"><img alt="" src="http://via.placeholder.com/500x320/000/fff"></a></li>
              <li class="col-xs-4 col-4"><a href="#"><img alt="" src="http://via.placeholder.com/500x320/000/fff"></a></li>
              <li class="col-xs-4 col-4"><a href="#"><img alt="" src="http://via.placeholder.com/500x320/000/fff"></a></li>
              <li class="col-xs-4 col-4"><a href="#"><img alt="" src="http://via.placeholder.com/500x320/000/fff"></a></li>
              <li class="col-xs-4 col-4"><a href="#"><img alt="" src="http://via.placeholder.com/500x320/000/fff"></a></li>
              <li class="col-xs-4 col-4"><a href="#"><img alt="" src="http://via.placeholder.com/500x320/000/fff"></a></li>
            </ul>
          </div>
        </div>
        
        <!-- BACK TO TOP BUTTON --> 
        <!-- COPY RIGHT --> 
      </div>
      <div class="copyright">
        <hr>
        <div class="row justify-content-center">
          <div class="col-sm-6">
            <div class="copyRight_text text-center">
              <p>Copyright  &copy; <span id="year"></span> Frontier Semiconductor.  All rights reserved </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/jquery/jquery-min.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/jquery/plugins.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/jquery/jquery.animateNumber.min.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/bootstrap/js/bootstrap.min.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/owl-carousel/js/owl.carousel.min.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/wow/wow.min.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/jquery/jquery.mainmenu.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/jquery/jquery.nivo.slider.pack.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/assets/jquery/magnific-popup.min.js')); ?>"></script> 
  <script src="<?php echo e(URL::asset('fsm_all_web_file/js/custom.js')); ?>"></script>
  </body>
  </html>